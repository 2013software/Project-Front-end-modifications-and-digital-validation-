package com.stadium.entity;

import lombok.Data;

@Data
public class StVenue {
    int id;
    int timeid;
    String time;
    int venueid;
    String location;
    int useid;
}
