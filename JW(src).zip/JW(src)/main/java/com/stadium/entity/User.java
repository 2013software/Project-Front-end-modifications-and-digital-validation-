package com.stadium.entity;

import lombok.Data;

@Data
public class User {
    int userid;
    String username;
    String password;
    String telephone;
    String identity;
}
